<?php
header ('Location:http://www.lokomedia.web.id/');
?>