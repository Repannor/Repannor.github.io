
<?php 
echo "<div class='wrapper' style='padding-top:0px;'><br>
	<center>Lokomedia web Sekolah © ".date('Y')." All Right Reserved</center>
</div>";


